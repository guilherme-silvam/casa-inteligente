function ligar(dispositivo) {
  fetch(`http://localhost:3000/${dispositivo}/ligar`)
    .then(res => alert(`${dispositivo} ligado`));
}
function desligar(dispositivo) {
  fetch(`http://localhost:3000/${dispositivo}/desligar`)
    .then(res => alert(`${dispositivo} desligado`));
}
