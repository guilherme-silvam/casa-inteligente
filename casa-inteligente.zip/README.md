# Projeto Casa Inteligente

Controle dispositivos como luzes e TV via navegador.  
Front-end em HTML/CSS/JS, back-end em Node.js e integração com ESP32.

## Como rodar

1. Instale Node.js
2. Vá para a pasta `backend` e execute:
```
npm install express cors
node server.js
```

3. Abra `frontend/index.html` no navegador.

## ESP32
- Código em `dispositivos/esp32/esp32-control.ino`
- Use Arduino IDE para subir
