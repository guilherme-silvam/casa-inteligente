const express = require('express');
const app = express();
const cors = require('cors');
app.use(cors());

app.get('/:dispositivo/ligar', (req, res) => {
  const { dispositivo } = req.params;
  console.log(`Ligando ${dispositivo}`);
  res.send(`${dispositivo} ligado`);
});

app.get('/:dispositivo/desligar', (req, res) => {
  const { dispositivo } = req.params;
  console.log(`Desligando ${dispositivo}`);
  res.send(`${dispositivo} desligado`);
});

app.listen(3000, () => console.log("Servidor rodando na porta 3000"));
