from flask import Flask, render_template, request
import samsungctl
import json

app = Flask(__name__)

with open("samsung_config.json") as f:
    config = json.load(f)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/control", methods=["POST"])
def control():
    key = request.form.get("key")
    with samsungctl.Remote(config) as remote:
        remote.control(key)
    return f"Enviado comando: {key}"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)